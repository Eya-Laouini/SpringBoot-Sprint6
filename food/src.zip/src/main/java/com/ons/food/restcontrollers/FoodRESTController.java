package com.ons.food.restcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ons.food.model.entities.Food;
import com.ons.food.service.FoodService;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class FoodRESTController {
	
	@Autowired
	FoodService foodService;
	
	@RequestMapping(method=RequestMethod.GET)
	List<Food> getAllFood()
	{
		return foodService.getAllFood();
	}
	@RequestMapping(value="/{id}",method = RequestMethod.GET)
	public Food getProduitById(@PathVariable("id") Long id) {
		return foodService.getFood(id);
	 }
	@RequestMapping(method = RequestMethod.POST)
	public Food createfood(@RequestBody Food food) {
		return foodService.saveFood(food);
	}
	@RequestMapping(method = RequestMethod.PUT)
	public Food updateFood(@RequestBody Food food) {
	return foodService.updateFood(food);
	}
	@RequestMapping(value="/{id}",method = RequestMethod.DELETE)
	public void deleteFood(@PathVariable("id") Long id)
	{
		foodService.deleteFoodById(id);
	}
	@RequestMapping(value="/foodschx/{idChoix}",method = RequestMethod.GET)
	public List<Food> getFoodsByChoixId(@PathVariable("idChoix") Long idChoix) {
		return foodService.findByChoixIdChoix(idChoix);
	}

	@RequestMapping(value="/foodsByName/{nom}",method = RequestMethod.GET)
	public List<Food> findByNomProduitContains(@PathVariable("nom") String nom) {
	return foodService.findByNomFoodContains(nom);
	}



}
