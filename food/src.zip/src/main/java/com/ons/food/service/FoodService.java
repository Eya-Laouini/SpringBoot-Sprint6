package com.ons.food.service;

import java.util.List;

import com.ons.food.model.entities.Choix;
import com.ons.food.model.entities.Food;

public interface FoodService {
	Food saveFood(Food f);
	Food updateFood(Food f);
	void deleteFood(Food f);
	void deleteFoodById(Long id);
	Food getFood(Long id);
	List<Food> getAllFood();
	List<Food> findByNomFood(String nom);
	List<Food> findByNomFoodContains(String nom);
	List<Food> findByNomPrix (String nom, Double prix);
	List<Food> findByChoix (Choix choix);
	List<Food> findByChoixIdChoix(Long id);
	List<Food> findByOrderByNomFoodAsc();
	List<Food> trierFoodNomsPrix();


}
