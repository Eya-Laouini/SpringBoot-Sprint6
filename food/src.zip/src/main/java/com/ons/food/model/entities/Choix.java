package com.ons.food.model.entities;


import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Choix {
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Long idChoix;
	private String nomChoix;
	private String caracteristiqueChoix;
	
	
	@OneToMany (mappedBy = "choix")
	@JsonIgnore
	private List<Food> food;
	public List<Food> getfood(){
		return food;
	}
	
	//public Choix() {
	//	super();
	//}

	public String getNomChoix() {
		return nomChoix;
	}
	public void setNomChoix(String nomChoix) {
		this.nomChoix = nomChoix;
	}


	public String getCaracteristiqueChoix() {
		return caracteristiqueChoix;
	}


	public void setCaracteristiqueChoix(String caracteristiqueChoix) {
		this.caracteristiqueChoix = caracteristiqueChoix;
	}


	public Long getIdChoix() {
		return idChoix;
	}


	public void setIdChoix(Long idChoix) {
		this.idChoix = idChoix;
	}
	
	
}