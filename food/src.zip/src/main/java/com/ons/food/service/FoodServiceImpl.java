package com.ons.food.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ons.food.model.entities.Choix;
import com.ons.food.model.entities.Food;
import com.ons.food.repos.FoodRepository;

@Service
public class FoodServiceImpl implements FoodService{

	@Autowired
	FoodRepository foodRepository;
	
	
	@Override
	public Food saveFood(Food f) {
		return 	foodRepository.save(f);
	}

	@Override
	public Food updateFood(Food f) {
		return 	foodRepository.save(f);
	}

	@Override
	public void deleteFood(Food f) {
		 	foodRepository.delete(f);
		
	}

	@Override
	public void deleteFoodById(Long id) {
		foodRepository.deleteById(id);
	}

	@Override
	public Food getFood(Long id) {
		return foodRepository.findById(id).get();
	}

	@Override
	public List<Food> getAllFood() {
		return foodRepository.findAll();
	}

	@Override
	public List<Food> findByNomFood(String nom) {
		return foodRepository.findByNomFood(nom);
	}

	@Override
	public List<Food> findByNomFoodContains(String nom) {
		return foodRepository.findByNomFoodContains(nom) ;
	}

	@Override
	public List<Food> findByNomPrix(String nom, Double prix) {
		
		return foodRepository.findByNomPrix(nom, prix);
	}

	@Override
	public List<Food> findByChoix(Choix choix) {
		
		return foodRepository.findByChoix(choix);
	}

	@Override
	public List<Food> findByChoixIdChoix(Long id) {
		
		return foodRepository.findByChoixIdChoix(id);
	}

	@Override
	public List<Food> findByOrderByNomFoodAsc() {
		
		return foodRepository.findByOrderByNomFoodAsc();
	}

	@Override
	public List<Food> trierFoodNomsPrix() {
		
		return foodRepository.trierFoodNomsPrix();
	}

}
